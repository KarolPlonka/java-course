interface Przeszukiwalne{
    boolean czyPasuje(String wzorzec);
}